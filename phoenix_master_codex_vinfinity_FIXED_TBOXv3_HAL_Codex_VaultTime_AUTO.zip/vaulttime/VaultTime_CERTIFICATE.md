# VaultTime Certificate
**Bundle:** phoenix_master_codex_vinfinity_fixed  
**Owner:** Adam Henry Nagle <cainkilledabel@icloud.com>  
**License:** VaultTime-Private-v1  
**Created:** 2025-08-21T18:27:32Z

## Codex Aggregate
```
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
```

## Signature
Algorithm: RSA-4096-SHA256
Fingerprint: 3ba7edaeb8aace6fbe263f58f728d6a2a735f08fd9b6863f7becb4959680d33e

Signature (base64):
```
DAzv+u4uuH2V5Vz+u6VtX1g1L4aEPcz7E29BqvprFukrZhzyXvUccZ0yoEsZr5ZHVcCMzM9GIwPzl5Pgl48iRElvbuN63Q/yy/DqouK2+T0DZYO8O+4EowH7zovFg29swbcbaGUSqv//hwRf39sVnCXiK6HpdD8JtOUJi/K7mF9ud6eWJOkQkRN6RsYOrYyH5VCodnY1hZSQVLEgucLYcTLSInWCHQrjAaTm/+PlSj8ldE/PtwCnQ2dKvy0vFjNkKEcvWZdEspRNdzA4ATduvmekM92bCILrxaXj2ox7+1K9kFJ+LwHkxcWnh+cohmbdwI5kWz51vDYG23dScYOrPRfFLc220PFQnOq2s0A5ikMy0+LiifDOGgpSBGAFzHoyEsKL32cJ4n6gcKUaeUyyYETglQ9W2GQQGWpxmGGqPyQTgdLZJON5SUbUbeRNqAparS7KWIfW0TAlbz014VDN/pAf601aN4ch87BIQuOD5/LPzc6ZvdLSC8ovcp6Zzj03tFdDNup3D8mZA6qsQmeRNlf9tEn0W27bEuTOywbO5Cj+EdlgRWGsQA2ho3arOyx5/h0MrZkFxH6GfqUzz1jVk52Fl3c5Urq9r1jTUmMDV9bdKsfz2OQdWx2BjAVqkJ7QPYNF9AGlq9QNOib4sLNTlQ4sUPdSAwrXIOL9Qi+yR+0=
```

## Verify (OpenSSL)
```bash
python3 onboarding_bundle_v1/scripts/hal_hardener.py
openssl dgst -sha256 -verify vaulttime/public_key.pem -signature <(base64 -d vaulttime/signature.b64) vaulttime/signing_blob.json
```
