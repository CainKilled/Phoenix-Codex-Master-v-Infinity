#!/usr/bin/env bash
set -euo pipefail
python3 "$(dirname "$0")/../onboarding_bundle_v1/scripts/hal_hardener.py"
if command -v openssl >/dev/null 2>&1; then
  openssl dgst -sha256 -verify "$(dirname "$0")/public_key.pem"     -signature <(base64 -d "$(dirname "$0")/signature.b64")     "$(dirname "$0")/signing_blob.json"
  echo "[VaultTime] Signature verified."
else
  echo "[VaultTime] OpenSSL not available; cannot verify signature."
  exit 2
fi
